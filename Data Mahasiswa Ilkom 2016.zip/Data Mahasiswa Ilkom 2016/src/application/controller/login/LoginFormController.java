package application.controller.login;

import java.sql.*;

import com.jfoenix.controls.*;
import com.sun.glass.ui.Menu;

import application.databaseConnection.databaseConnection;
import application.main.Home;
import application.main.Login;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

public class LoginFormController {

	@FXML JFXTextField userfield;
	@FXML JFXPasswordField passfield;
	
	Connection connection				= null;
	ResultSet resultSet					= null;
	PreparedStatement preparedStatement = null;
	
	
	
	
	
	public LoginFormController() {
		
		connection = databaseConnection.dbConnect();
		
	}
	
	
	
	
	
	
	@FXML
	public void signinAction(ActionEvent e) {
		
		String sql      = 	" SELECT * FROM login WHERE username = ? AND password = ? ";
		String username = 	userfield.getText().toString();
		String password = 	passfield.getText().toString();
		
		
		
		try {
			
			preparedStatement = connection.prepareStatement(sql);
			
			preparedStatement.setString(1, username);
			preparedStatement.setString(2, password);
			
			resultSet = preparedStatement.executeQuery();
			
			
			
			
			
			
			
			if(!resultSet.next()) {
				
				String title	= " Peringatan ";
				String header	= " Gagal ";
				String message	= " Masukkan username dan password yang benar ";
				
				warnBox(title, header, message);
				
			}else {
				
				String title	= " Konfirmasi ";
				String header	= " Sukses ";
				String message	= " Anda berhasil Sign in ";
				
				infoBox(title, header, message);
				
				
				
				
				Node node         = (Node)e.getSource();
				Stage dialogStage = new Stage();
				dialogStage       = (Stage)node.getScene().getWindow();
				dialogStage.close();
				
				
				
				
				Stage newWindow = new Stage();
				newWindow.setTitle(" Home ");
			
				Scene scene = new Scene(FXMLLoader.load(Home.class.getResource("/application/controller/home/Home.fxml")));
				newWindow.setScene(scene);
				newWindow.show();
				
			}
			
			
			
			
			
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		
		
		
		
		
	}
	
	
	
	public static void warnBox(String title, String header, String message) {
		
		Alert alert = new Alert(AlertType.WARNING);
		alert.setTitle(title);
		alert.setHeaderText(header);
		alert.setContentText(message);
		alert.showAndWait();
		
	}
	
	public static void infoBox(String title, String header, String message) {
		
		Alert alert = new Alert(AlertType.CONFIRMATION);
		alert.setTitle(title);
		alert.setHeaderText(header);
		alert.setContentText(message);
		alert.showAndWait();
		
	}
	
	
	
	
	
	
	
}
