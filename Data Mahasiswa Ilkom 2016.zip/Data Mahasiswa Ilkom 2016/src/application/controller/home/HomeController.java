package application.controller.home;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.jfoenix.controls.JFXButton;

import application.databaseConnection.databaseConnection;
import application.main.Data;
import application.main.InputForm;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class HomeController {
	
	@FXML private AnchorPane home;
	@FXML private JFXButton tombolIsiData, tombolLihatData, tombolLihatGrafik;
	Stage stage;
	Scene scene;
	
	private Connection        connection		= null;
	private PreparedStatement preparedStatement = null;
	private ResultSet         resultSet			= null;
	
	
	public HomeController() {
		connection = databaseConnection.dbConnect();
	}
	
	
	@FXML
	public void isiData(ActionEvent e) throws Exception {
		
		stage = new Stage();
		stage.setTitle(" Form Data ");
		scene = new Scene(FXMLLoader.load(InputForm.class.getResource("/application/controller/inputForm/InputForm.fxml")));
		
		
		stage.setScene(scene);
		stage.show();
		
	}
	
	
	
	
	@FXML
	public void lihatData(ActionEvent e) throws Exception {
		
		stage = new Stage();
		stage.setTitle(" Data Mahasiswa ");
		scene = new Scene(FXMLLoader.load(Data.class.getResource("/application/controller/data/Data.fxml")));
		
		
		stage.setScene(scene);
		stage.show();
		
	}
	
	
	
	@FXML
	public void lihatGrafik(ActionEvent e) throws Exception {
		
	}
	
}
