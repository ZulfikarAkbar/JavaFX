package application.controller.inputForm;

import java.sql.*;

import com.jfoenix.controls.*;

import application.databaseConnection.databaseConnection;
import application.main.listMahasiswa;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;

public class InputFormController {
	
	@FXML private JFXTextField                inputNRM, inputNama, inputTempatLahir, inputAlamat, 
					                          inputAsalSekolah, inputContact;
	
	@FXML private JFXDatePicker               inputTanggalLahir;
	@FXML private JFXButton                   tombolSimpan;
	@FXML private TableView < listMahasiswa > tabel_mahasiswa;
	
	@FXML private TableColumn <?,?>           kolom_NRM, kolom_nama, kolom_tanggal_lahir, kolom_tempat_lahir,
									          kolom_alamat, kolom_asal_sekolah, kolom_contact;
	
	
	Connection connection				= null;
	ResultSet resultSet					= null;
	PreparedStatement preparedStatement = null;
	private ObservableList <listMahasiswa> data;
	
	
	
	
	public InputFormController() {
		
		connection = databaseConnection.dbConnect();
		data       = FXCollections.observableArrayList();
	}
	
	
	@FXML
	public void simpanAction(ActionEvent e) {
		
		String sql = "INSERT INTO data_mahasiswa (nomor_registrasi, nama, tempat_lahir, tanggal_lahir, alamat, asal_sekolah, contact) VALUES (?, ?, ?, ?, ?, ?, ?)";
		
		
		
		String nrm 			= inputNRM         .getText()          .toString();
		String nama  		= inputNama        .getText()          .toString();
		String tempatLahir  = inputTempatLahir .getText()          .toString();
		String alamat 		= inputAlamat      .getText()          .toString();
		String asalSekolah 	= inputAsalSekolah .getText()          .toString();
		String contact 		= inputContact     .getText()          .toString();
		String tanggalLahir = inputTanggalLahir.getDayCellFactory().toString();
		
		
		
		try {
			
			preparedStatement = connection.prepareStatement(sql);
			
			preparedStatement.setString(1, nrm          );
			preparedStatement.setString(2, nama         );
			preparedStatement.setString(3, tempatLahir  );
			preparedStatement.setString(4, tanggalLahir );
			preparedStatement.setString(5, alamat       );
			preparedStatement.setString(6, asalSekolah  );
			preparedStatement.setString(7, contact      );
			
			
			// resultSet = preparedStatement.executeQuery();
			int update = preparedStatement.executeUpdate();
			
			
			if(update==1) {
				
				String title   = " Konfirmasi penyimpanan " ,
					   header  = " Sukses Menyimpan "       , 
					   message = " Data berhasil disimpan " ;
						
				infoBox(title, header, message);
				setCellTable();
				loadDataFromDatabase();
				
			}
			
			
			
			
			
			
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		
		
		
	}
	
	
	
	
	
	public void utility() {
		
		setCellTable();
		loadDataFromDatabase();
		
	}
	
	
	
	
	
	
	
	
	public void setCellTable(){
		
		kolom_NRM              .setCellValueFactory(  new PropertyValueFactory  <>  ("nomor_registrasi") );
		kolom_nama             .setCellValueFactory(  new PropertyValueFactory  <>  ("nama")	         );
		kolom_tempat_lahir     .setCellValueFactory(  new PropertyValueFactory  <>  ("tempat_lahir")     );
		kolom_tanggal_lahir    .setCellValueFactory(  new PropertyValueFactory  <>  ("tanggal_lahir")    );
		kolom_alamat           .setCellValueFactory(  new PropertyValueFactory  <>  ("alamat")	         );
		kolom_asal_sekolah     .setCellValueFactory(  new PropertyValueFactory  <>  ("asal_sekolah")     );
		kolom_contact          .setCellValueFactory(  new PropertyValueFactory  <>  ("contact")	         );  
		
	}
	
	
	
	
	
	
	
	public void loadDataFromDatabase() {
		data.clear();
		
		try{
			
			String sql           = " SELECT * FROM data_mahasiswa ";
			preparedStatement    = connection.prepareStatement(sql);
			resultSet            = preparedStatement.executeQuery();
			
			
			while(resultSet.next()){
				listMahasiswa listmahasiswa = new listMahasiswa (  
														  resultSet.getString (1),
				                                          resultSet.getString (2),
				                                          resultSet.getString (3),
				                                          resultSet.getString (4),
				                                          resultSet.getString (5),
				                                          resultSet.getString (6),
				                                          resultSet.getString (7)
		                                               );
				data.add(listmahasiswa);
			}
			
		} catch (Exception ex){
			ex.printStackTrace();
		}
		
		tabel_mahasiswa.setItems(data);
	}
	
	
	
	
	
	
	
	
	
	public static void infoBox(String title, String header, String message) {
		Alert alert = new Alert(AlertType.CONFIRMATION);
		alert.setTitle(title);
		alert.setHeaderText(header);
		alert.setContentText(message);
		alert.showAndWait();
	}
	
	
	
}
