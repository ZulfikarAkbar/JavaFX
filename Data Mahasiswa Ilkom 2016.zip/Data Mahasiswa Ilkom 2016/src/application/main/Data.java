package application.main;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class Data extends Application{

	
	private Stage dataStage;
	private BorderPane dataContainer;
	private AnchorPane tabelDataPane, dataHeader;
	
	FXMLLoader loader;
	Scene scene;
	
	
	public void start(Stage dataStage) {
		this.dataStage = dataStage;
		this.dataStage.setTitle(" Data ");
		showData();
	}
	
	
	
	
	
	public void showData() {
		// TODO Auto-generated method stub
		try {
			
			loader = new FXMLLoader();
			loader.setLocation(InputForm.class.getResource("/application/controller/data/Data.fxml"));
			dataContainer = (BorderPane)loader.load();
			scene = new Scene(dataContainer);
			scene.getStylesheets().add(InputForm.class.getResource("/application/css/application.css").toExternalForm());
			dataStage.setScene(scene);
			dataStage.show();
			
		}catch(Exception e) {
			
			e.printStackTrace();
		}
	}
	
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}

}
