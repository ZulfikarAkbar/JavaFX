package application.main;

import com.jfoenix.controls.JFXButton;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class Home extends Application{

	
	
	private AnchorPane home;
	private Stage homeStage;
	private JFXButton tombolIsiData, tombolLihatData, tombolLihatGrafik;
	FXMLLoader loader;
	Scene scene;
	
	
	public void start(Stage homeStage) {
		
		this.homeStage = homeStage;
		this.homeStage.setTitle(" Sistem Data Mahasiswa ");
		showHome();
		

	}
	
	public void showHome() {
		// TODO Auto-generated method stub
		try {
			
			loader = new FXMLLoader();
			loader.setLocation(Home.class.getResource("/application/controller/home/Home.fxml"));
			home = (AnchorPane)loader.load();
			scene = new Scene(home);
			scene.getStylesheets().add(Home.class.getResource("/application/css/application.css").toExternalForm());
			homeStage.setScene(scene);
			homeStage.show();
			
		}catch(Exception e) {
			
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}

}
