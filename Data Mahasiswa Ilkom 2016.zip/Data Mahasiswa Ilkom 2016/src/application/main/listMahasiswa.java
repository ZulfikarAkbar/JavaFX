package application.main;

public class listMahasiswa {

	private String nomor_registrasi, nama, tanggal_lahir, tempat_lahir, contact, asal_sekolah, alamat;
	
	
	
	
	
	
	public listMahasiswa( String nomor_registrasi , String nama    , String tanggal_lahir , String alamat,
						  String tempat_lahir     , String contact , String asal_sekolah                  )
	
	{
		
		this.nama               = nama;
		this.contact            = contact;
		this.alamat             = alamat;
		this.tempat_lahir       = tempat_lahir;
		this.asal_sekolah       = asal_sekolah;
		this.tanggal_lahir      = tanggal_lahir;
		this.nomor_registrasi   = nomor_registrasi;
		
	}
	
	
	
	
	
	
	
	
	public String getNomorRegistrasi()  {  return nomor_registrasi;  }
	public String getNama() 			{  return nama;              }
	public String getContact() 			{  return contact;           }
	public String getAsalSekolah() 		{  return asal_sekolah;      }
	public String getAlamat() 			{  return alamat;            }
	public String getTempatLahir() 		{  return tempat_lahir;      }
	public String getTanggalLahir() 	{  return tanggal_lahir;     }
	
	
	
	
	
	
	
	
	
	public void setNomorRegistrasi(String nomor_registrasi)   {  this.nomor_registrasi = nomor_registrasi;  }
	public void setNama           (String nama)				  {  this.nama             = nama;				}
	public void setContact        (String contact)            {  this.contact          = contact; 			}
	public void setAsalSekolah    (String asal_sekolah)       {  this.asal_sekolah     = asal_sekolah;		}
	public void setAlamat         (String alamat) 			  {  this.alamat           = alamat;			}
	public void setTempatLahir    (String tempat_lahir)       {  this.tempat_lahir     = tempat_lahir;		}
	public void setTanggalLahir   (String tanggal_lahir)      {  this.tanggal_lahir    = tanggal_lahir;	    }
	
	
}
