package application.main;
	
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;

/*
 * author : Zulfikar Akbar
 */


/*
 * 		Class Login berisi 1 method utama dan 3 method kebutuhan :
 * 			1. start(Stage <var> )  : menjadi bagian yang paling utama dari semua aplikasi JavaFX
 * 			2. showLoginRoot() 		: menampilkan jendela Login secara utuh
 * 			3. showLoginHeader()	: menampilkan bagian header dari login
 * 			4. showLoginForm()		: menampilkan bagian dari login form
 * 
 */

public class Login extends Application {
	
	
	private BorderPane loginRoot;
	private AnchorPane loginHeader, loginForm;
	private Stage login;
	
	FXMLLoader loader;
	Scene scene;
	
	
	/*	method ini di dalamnya berguna :
	*		1. memastikan bahwa parameter Class Stage yang variabelnya login "sama dengan" Class Stage
	*		   yang di private
	*		2. menampilkan judul dari aplikasi yang dijalankan
	*		3. meletakkan semua method yang kita butuhkan untuk kemudian didefinisikan. Sekarang kita butuh 3 method yaitu
	*		   showLoginRoot(), showLoginHeader(), showLoginForm()
	*/	
	
	
	public void start(Stage login) {
		
		this.login = login;
		this.login.setTitle(" Sistem Data Mahasiswa ");
		showLoginRoot();
		showLoginHeader();
		showLoginForm();
		

	}
	
	
	/*
	 * 	method ini di dalamnya terdapat try-catch block
	 * 	block try akan menjalankan sebuah Class FXMLLoader dimana class tersebut berfungsi untuk
	 * 		menjalankan GUI dari aplikasi yang sebelumnya dibuat menggunakan Scene builder dan 
	 * 		berekstensi .fxml.
	 * 
	 * 		Class FXMLLoader kemudian akan mencari lokasi dari file.fxml tersebut menggunakan 
	 * 		absolute path dari file.fxml.
	 * 
	 * 		Setelah lokasi ditemukan, kemudian akan dipastikan jenis dari container yang digunakan pada file.fxml
	 * 		contohnya borderpane, anchorpane, dan lainnya. kemudian dilakukanlah load container itu.
	 * 		Dalam hal ini container berupa BorderPane		
	 * 
	 * 		Setelah dipastikan, maka container tersebut akan digunakan menjadi sebuah scene di dalam class Scene.
	 * 		Pada Class Scene, bisa ditambahkan sebuah file.css untuk mempermanis tampilan aplikasi kita.
	 * 
	 * 		Setelah Scene dipersiapkan, kemudian Class Stage akan mengambil Scene menjadi bagian dari dirinya untuk
	 * 		kemudian ditampilkan.
	 * 
	 */
	
	
	public void showLoginRoot() {
		// TODO Auto-generated method stub
		try {
			
			loader = new FXMLLoader();
			loader.setLocation(Login.class.getResource("/application/controller/login/LoginRoot.fxml"));
			loginRoot = (BorderPane)loader.load();
			scene = new Scene(loginRoot);
			scene.getStylesheets().add(Login.class.getResource("/application/css/application.css").toExternalForm());
			login.setScene(scene);
			login.show();
			
		}catch(Exception e) {
			
			e.printStackTrace();
		}
		
	}

	
	
	/*
	 * 	method ini di dalamnya terdapat try-catch block
	 * 	block try akan menjalankan sebuah Class FXMLLoader dimana class tersebut berfungsi untuk
	 * 		menjalankan GUI dari aplikasi yang sebelumnya dibuat menggunakan Scene builder dan 
	 * 		berekstensi .fxml.
	 * 
	 * 		Class FXMLLoader kemudian akan mencari lokasi dari file.fxml tersebut menggunakan 
	 * 		absolute path dari file.fxml.
	 * 
	 * 		Setelah lokasi ditemukan, kemudian akan dipastikan jenis dari container yang digunakan pada file.fxml
	 * 		contohnya borderpane, anchorpane, dan lainnya. kemudian dilakukanlah load container itu.
	 * 		Dalam hal ini container berupa AnchorPane
	 * 
	 * 		Setelah AnchorPane diload, maka selanjutnya melakukan peletakkan AnchorPane pada bagian atas dari BorderPane
	 * 
	 */
	
	
	public void showLoginHeader() {
		// TODO Auto-generated method stub
		try {
			
			loader = new FXMLLoader();
			loader.setLocation(Login.class.getResource("/application/controller/login/LoginHeader.fxml"));
			loginHeader = (AnchorPane)loader.load();
			loginRoot.setTop(loginHeader);
		
			
		}catch(Exception e) {
			
			e.printStackTrace();
		}
		
	}

	
	
	
	/*
	 * 	method ini di dalamnya terdapat try-catch block
	 * 	block try akan menjalankan sebuah Class FXMLLoader dimana class tersebut berfungsi untuk
	 * 		menjalankan GUI dari aplikasi yang sebelumnya dibuat menggunakan Scene builder dan 
	 * 		berekstensi .fxml.
	 * 
	 * 		Class FXMLLoader kemudian akan mencari lokasi dari file.fxml tersebut menggunakan 
	 * 		absolute path dari file.fxml.
	 * 
	 * 		Setelah lokasi ditemukan, kemudian akan dipastikan jenis dari container yang digunakan pada file.fxml
	 * 		contohnya borderpane, anchorpane, dan lainnya. kemudian dilakukanlah load container itu.
	 * 		Dalam hal ini container berupa AnchorPane
	 * 
	 * 		Setelah AnchorPane diload, maka selanjutnya melakukan peletakkan AnchorPane pada bagian tengah dari BorderPane
	 * 
	 */
	
	
	public void showLoginForm() {
		// TODO Auto-generated method stub
		try {
			
			loader = new FXMLLoader();
			loader.setLocation(Login.class.getResource("/application/controller/login/LoginForm.fxml"));
			loginForm = (AnchorPane)loader.load();
			loginRoot.setCenter(loginForm);
			
			
		}catch(Exception e) {
			
			e.printStackTrace();
		}
		
	}
	
	
	
	
	
	

	public static void main(String[] args) {
		launch(args);
	}
}
