
package application.main;

import java.io.IOException;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class InputForm extends Application{

	private Stage formInput;
	private BorderPane inputFormRoot;
	private AnchorPane inputFormHeader, inputForm;
	
	FXMLLoader loader;
	Scene scene;
	
	
	public void start(Stage formInput) {
		this.formInput = formInput;
		this.formInput.setTitle(" Input Form ");
		showInputFormRoot();
	}
	
	
	
	
	
	public void showInputFormRoot() {
		// TODO Auto-generated method stub
		try {
			
			loader = new FXMLLoader();
			loader.setLocation(InputForm.class.getResource("/application/controller/inputForm/InputForm.fxml"));
			inputFormRoot = (BorderPane)loader.load();
			scene = new Scene(inputFormRoot);
			scene.getStylesheets().add(InputForm.class.getResource("/application/css/application.css").toExternalForm());
			formInput.setScene(scene);
			formInput.show();
			
		}catch(Exception e) {
			
			e.printStackTrace();
		}
	}

	
	
	
	
	
	
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}

}
