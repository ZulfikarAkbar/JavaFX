package application.mainApp;



import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class mainCalculator extends Application {
	
	private Stage primaryStage;
	private AnchorPane calculatorPane;
	
	@Override
	public void start(Stage primaryStage){
		this.primaryStage=primaryStage;
		this.primaryStage.setTitle("Calculator");
		showCalculatorPane();
		
	}
	
	public void showCalculatorPane() {
		try{
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(mainCalculator.class.getResource("/application/view/calculator.fxml"));
			calculatorPane = (AnchorPane)loader.load();
			Scene scene = new Scene(calculatorPane);
			scene.getStylesheets().add(mainCalculator.class.getResource("/application/view/calculator.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.setResizable(false);
			primaryStage.show();
		} catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public Stage getPrimaryStage(){
		return primaryStage;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}
}
