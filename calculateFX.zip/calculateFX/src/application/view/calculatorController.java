package application.view;

import javafx.event.ActionEvent;

import javafx.fxml.FXML;

import javafx.scene.control.Button;

import javafx.scene.control.TextField;

public class calculatorController{ 
	
	
    @FXML
	private TextField textField;
    
    private int decimalClick = 0;
     
    private String generalOperation;
    
    private Double firstDouble;
    
	
	@FXML
	private void generalHandlerAction(ActionEvent e){
		generalOperation = ((Button)e.getSource()).getText();
		switch (generalOperation) {
		case "C":
					textField.setText("");
					decimalClick=0;
					break;
		case "+/-":
					double plusMinus = Double.parseDouble(String.valueOf(textField.getText()));
					plusMinus = plusMinus*(-1);
					textField.setText(String.valueOf(plusMinus));
					break;
		case "+":
		case "-":
		case "*":
		case "/":
		case "%":
					String currentText = textField.getText();
					firstDouble = Double.parseDouble(currentText);
					textField.setText("");
					decimalClick=0;
					break;
		default:
		}
	}
	@FXML
	private void handlerDigitAction(ActionEvent e){
		String digit = ((Button)e.getSource()).getText();
		String oldText = textField.getText();
		String newText = digit+oldText;
		textField.setText(newText);
	}
	@FXML
	private void decimalHandlerAction(ActionEvent e){
		if(decimalClick==0){
			String decimal = ((Button)e.getSource()).getText();
			String oldText = textField.getText();
			String newText = decimal+oldText;
			textField.setText(newText);
			decimalClick=1;		
		}
	}
	@FXML
	private void resultHandlerAction(ActionEvent e){
		double secondDouble;
		double result=0;
		String secondText = textField.getText();
		secondDouble = Double.parseDouble(secondText);
		
		switch(generalOperation){
		case "+":
					result = firstDouble+secondDouble;
					break;
		case "-":
					result = firstDouble-secondDouble;
					break;
		case "*":
					result = firstDouble*secondDouble;
					break;
		case "/":
					result = firstDouble/secondDouble;
					break;
		default:
				
		}
		
		String format = String.format("%.1f", result);
		textField.setText(format);
	}

}
